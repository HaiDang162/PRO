﻿# DoIt.Now - LÀM ĐI-CHỜ CHI | JAVA CRAFTSMAN

### Bạn tìm thấy trong "nhà kho" này các tài nguyên liên quan đến Lập trình OOP với Java
* Java OOP Cheat Sheet
* Các lát cắt (atlas) kiến thức quan trọng
* Project CRUD mẫu - PetCare System
* Source code - Dependency Injection
* Source code - Mảng đối tượng
* Video bài giảng - [giáo.làng channel](https://www.youtube.com/c/giáolàng)
* Đang cập nhật...


### Cảm ơn các thế hệ sinh viên đã nhiệt tình ủng hộ, kiên nhẫn & chịu đựng khi tham gia bài giảng cùng giáo. Các bạn mãi là niềm cảm hứng bất tận cho ngọn lửa nhiệt huyết trong giáo luôn luôn bùng cháy! 
### Welcome mọi feedback!

### HAPPY CODE | HAPPY MONEY | HAPPY LIFE

#### © 2022 Bản quyền thuộc về giáo.làng | fb/giao.lang.bis | youtube.com/c/giáolàng